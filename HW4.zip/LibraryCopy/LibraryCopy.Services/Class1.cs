﻿namespace LibraryCopy.Services {
    public class Class1 {

    }
}
